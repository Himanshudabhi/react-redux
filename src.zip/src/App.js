import { Provider } from 'react-redux';
import Header from './component/Header';
import Store from './store/Store';
import './Custom.css';
import Cart from './component/Cart';
import WishList from './component/WishList';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useState, useEffect } from 'react';
import { auth } from '../src/component/firebase';
import LoginForm from './component/LoginForm';
// import Signupform from '../src/component/Signupform';
// import Loginform from '../src/component/LoginForm';
// import Home from './pages/Home';
// import Mobile from './component/Mobile';
// import Welcome from './Welcome';

const App =() => {
  // const [username, setusername] = useState("");
  // useEffect(() => {
  //     auth.onAuthStateChanged((user)=>{
  //         if(user){
  //             setusername(user.displayName);
  //         }
  //         else setusername("")
  //     })
  // }, []);
  return (
    <>
    {/* <div className="App">
      <BrowserRouter>
      <Routes>
        <Route path="/" element={<Signupform />}/>
        <Route path="/login" element={<Loginform />}/>
        <Route path="/header" element={<Header/>}/>
      </Routes>
    </BrowserRouter>     */}

    
    {/* </div> */}
    {/* <Signupform/> */}
    <Provider store={Store}>
  

    <Header/>
    <Cart />
    <WishList />
    </Provider>
    {/* <LoginForm/> */}
 
    </>
  );
}

export default App;
